<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategories}leoclot>blockcategories_8f0ed7c57fca428f7e3f8e64d2f00918'] = 'Categorieën blok';
$_MODULE['<{blockcategories}leoclot>blockcategories_15a6f5841d9e4d7e62bec3319b4b7036'] = 'Voegt een blok met aanbevolen product categorieën toe.';
$_MODULE['<{blockcategories}leoclot>blockcategories_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Maximale diepte: Ongeldig nummer';
$_MODULE['<{blockcategories}leoclot>blockcategories_0cf328636f0d607ac24a5c435866b94b'] = 'Dynamische HTML: Ongeldige keuze';
$_MODULE['<{blockcategories}leoclot>blockcategories_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen bijgewerkt';
$_MODULE['<{blockcategories}leoclot>blockcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Instellingen';
$_MODULE['<{blockcategories}leoclot>blockcategories_19561e33450d1d3dfe6af08df5710dd0'] = 'Maximale diepte';
$_MODULE['<{blockcategories}leoclot>blockcategories_ef35cd8f1058f29151991e9ca94b36fb'] = 'Stel de maximale diepte van de niveaus weergegeven in dit blok (0 = oneindig)';
$_MODULE['<{blockcategories}leoclot>blockcategories_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'Dynamisch';
$_MODULE['<{blockcategories}leoclot>blockcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Ingeschakeld';
$_MODULE['<{blockcategories}leoclot>blockcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Uitgeschakeld';
$_MODULE['<{blockcategories}leoclot>blockcategories_e16f248b047fb7d0c97dcc19b17296a3'] = 'Activeer de dynamische (geanimeerde) mode voor subniveaus';
$_MODULE['<{blockcategories}leoclot>blockcategories_6b46ae48421828d9973deec5fa9aa0c3'] = 'Sorteren';
$_MODULE['<{blockcategories}leoclot>blockcategories_883f0bd41a4fcee55680446ce7bec0d9'] = 'Op positie';
$_MODULE['<{blockcategories}leoclot>blockcategories_54e4f98fb34254a6678f0795476811ed'] = 'Op naam';
$_MODULE['<{blockcategories}leoclot>blockcategories_cf3fb1ff52ea1eed3347ac5401ee7f0c'] = 'Oplopend';
$_MODULE['<{blockcategories}leoclot>blockcategories_e3cf5ac19407b1a62c6fccaff675a53b'] = 'Aflopend';
$_MODULE['<{blockcategories}leoclot>blockcategories_5f73e737cedf8f4ccf880473a7823005'] = 'Aantal kolommen in voettekst';
$_MODULE['<{blockcategories}leoclot>blockcategories_d5e74c74b1457c285adc8b2c2ab03767'] = 'Instelling van het aantal voettekstkolommen';
$_MODULE['<{blockcategories}leoclot>blockcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{blockcategories}leoclot>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categorieën';
$_MODULE['<{blockcategories}leoclot>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categorieën';
