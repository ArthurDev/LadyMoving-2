<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategories}leoclot>blockcategories_8f0ed7c57fca428f7e3f8e64d2f00918'] = 'Blocco categorie';
$_MODULE['<{blockcategories}leoclot>blockcategories_15a6f5841d9e4d7e62bec3319b4b7036'] = 'Aggiunge un blocco con le categorie di prodotto';
$_MODULE['<{blockcategories}leoclot>blockcategories_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Profondità massima: numero non valido.';
$_MODULE['<{blockcategories}leoclot>blockcategories_0cf328636f0d607ac24a5c435866b94b'] = 'HTML dinamico: scelta non valida.';
$_MODULE['<{blockcategories}leoclot>blockcategories_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blockcategories}leoclot>blockcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockcategories}leoclot>blockcategories_19561e33450d1d3dfe6af08df5710dd0'] = 'Profondità massima';
$_MODULE['<{blockcategories}leoclot>blockcategories_ef35cd8f1058f29151991e9ca94b36fb'] = 'Imposta la profondità massima di sottolivelli visualizzati in questo blocco (0 = infinito)';
$_MODULE['<{blockcategories}leoclot>blockcategories_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'Dinamico';
$_MODULE['<{blockcategories}leoclot>blockcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{blockcategories}leoclot>blockcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{blockcategories}leoclot>blockcategories_e16f248b047fb7d0c97dcc19b17296a3'] = 'Attiva modalità dinamica (animato) per sottolivelli.';
$_MODULE['<{blockcategories}leoclot>blockcategories_6b46ae48421828d9973deec5fa9aa0c3'] = 'Ordina';
$_MODULE['<{blockcategories}leoclot>blockcategories_883f0bd41a4fcee55680446ce7bec0d9'] = 'Per posizione';
$_MODULE['<{blockcategories}leoclot>blockcategories_54e4f98fb34254a6678f0795476811ed'] = 'Per nome';
$_MODULE['<{blockcategories}leoclot>blockcategories_cf3fb1ff52ea1eed3347ac5401ee7f0c'] = 'Crescente';
$_MODULE['<{blockcategories}leoclot>blockcategories_e3cf5ac19407b1a62c6fccaff675a53b'] = 'Decrescente';
$_MODULE['<{blockcategories}leoclot>blockcategories_5f73e737cedf8f4ccf880473a7823005'] = 'Quante colonne del footer preferisci?';
$_MODULE['<{blockcategories}leoclot>blockcategories_d5e74c74b1457c285adc8b2c2ab03767'] = 'Imposta il numero di colonne del footer.';
$_MODULE['<{blockcategories}leoclot>blockcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockcategories}leoclot>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categorie';
$_MODULE['<{blockcategories}leoclot>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categorie';
