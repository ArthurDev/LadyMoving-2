<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategories}leoclot>blockcategories_8f0ed7c57fca428f7e3f8e64d2f00918'] = 'Categories block';
$_MODULE['<{blockcategories}leoclot>blockcategories_15a6f5841d9e4d7e62bec3319b4b7036'] = 'Blok untuk menampilkan kategori produk.';
$_MODULE['<{blockcategories}leoclot>blockcategories_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Maximum depth: Invalid number.';
$_MODULE['<{blockcategories}leoclot>blockcategories_0cf328636f0d607ac24a5c435866b94b'] = 'Dynamic HTML: Invalid choice.';
$_MODULE['<{blockcategories}leoclot>blockcategories_c888438d14855d7d96a2724ee9c306bd'] = 'Seting berhasil disimpan';
$_MODULE['<{blockcategories}leoclot>blockcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Seting';
$_MODULE['<{blockcategories}leoclot>blockcategories_19561e33450d1d3dfe6af08df5710dd0'] = 'Maximum depth';
$_MODULE['<{blockcategories}leoclot>blockcategories_ef35cd8f1058f29151991e9ca94b36fb'] = 'Set the maximum depth of sublevels displayed in this block (0 = infinite)';
$_MODULE['<{blockcategories}leoclot>blockcategories_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'Dinamis';
$_MODULE['<{blockcategories}leoclot>blockcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktifkan';
$_MODULE['<{blockcategories}leoclot>blockcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Nonaktifkan';
$_MODULE['<{blockcategories}leoclot>blockcategories_e16f248b047fb7d0c97dcc19b17296a3'] = 'Aktifkan animasi untuk sublevel.';
$_MODULE['<{blockcategories}leoclot>blockcategories_6b46ae48421828d9973deec5fa9aa0c3'] = 'Urut';
$_MODULE['<{blockcategories}leoclot>blockcategories_883f0bd41a4fcee55680446ce7bec0d9'] = 'Berdasarkan posisi';
$_MODULE['<{blockcategories}leoclot>blockcategories_54e4f98fb34254a6678f0795476811ed'] = 'Berdasarkan nama';
$_MODULE['<{blockcategories}leoclot>blockcategories_cf3fb1ff52ea1eed3347ac5401ee7f0c'] = 'Ascending';
$_MODULE['<{blockcategories}leoclot>blockcategories_e3cf5ac19407b1a62c6fccaff675a53b'] = 'Descending';
$_MODULE['<{blockcategories}leoclot>blockcategories_5f73e737cedf8f4ccf880473a7823005'] = 'Berapa jumlah kolom pada footer yang Anda kehendaki?';
$_MODULE['<{blockcategories}leoclot>blockcategories_d5e74c74b1457c285adc8b2c2ab03767'] = 'Mengatur jumlah kolom pada footer';
$_MODULE['<{blockcategories}leoclot>blockcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Simpan';
$_MODULE['<{blockcategories}leoclot>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Kategori';
$_MODULE['<{blockcategories}leoclot>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Kategori';
