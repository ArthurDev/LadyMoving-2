<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategories}leoclot>blockcategories_8f0ed7c57fca428f7e3f8e64d2f00918'] = 'Blok kategorii';
$_MODULE['<{blockcategories}leoclot>blockcategories_15a6f5841d9e4d7e62bec3319b4b7036'] = 'Dodaje blok zawierający kategorie produktów.';
$_MODULE['<{blockcategories}leoclot>blockcategories_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Maksymalna głębokość: Nieprawidłowa wartość.';
$_MODULE['<{blockcategories}leoclot>blockcategories_0cf328636f0d607ac24a5c435866b94b'] = 'Dynamiczny HTML: Nieprawidłowy wybór.';
$_MODULE['<{blockcategories}leoclot>blockcategories_c888438d14855d7d96a2724ee9c306bd'] = 'Zaktualizowano ustawienia';
$_MODULE['<{blockcategories}leoclot>blockcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{blockcategories}leoclot>blockcategories_19561e33450d1d3dfe6af08df5710dd0'] = 'Maksymalna głębokość';
$_MODULE['<{blockcategories}leoclot>blockcategories_ef35cd8f1058f29151991e9ca94b36fb'] = 'Ustaw maksymalną ilość podpoziomów wyświetlaną w tym bloku (0=nieograniczone)';
$_MODULE['<{blockcategories}leoclot>blockcategories_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'Dynamicznie';
$_MODULE['<{blockcategories}leoclot>blockcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Włączone';
$_MODULE['<{blockcategories}leoclot>blockcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Wyłączone';
$_MODULE['<{blockcategories}leoclot>blockcategories_e16f248b047fb7d0c97dcc19b17296a3'] = 'Aktywuj tryb dynamiczny (animowany) dla pod-poziomów';
$_MODULE['<{blockcategories}leoclot>blockcategories_6b46ae48421828d9973deec5fa9aa0c3'] = 'Sortuj';
$_MODULE['<{blockcategories}leoclot>blockcategories_883f0bd41a4fcee55680446ce7bec0d9'] = 'Wg pozycji';
$_MODULE['<{blockcategories}leoclot>blockcategories_54e4f98fb34254a6678f0795476811ed'] = 'Wg nazwy';
$_MODULE['<{blockcategories}leoclot>blockcategories_cf3fb1ff52ea1eed3347ac5401ee7f0c'] = 'Rosnąco';
$_MODULE['<{blockcategories}leoclot>blockcategories_e3cf5ac19407b1a62c6fccaff675a53b'] = 'Malejąco';
$_MODULE['<{blockcategories}leoclot>blockcategories_5f73e737cedf8f4ccf880473a7823005'] = 'Ilość kolum stopki';
$_MODULE['<{blockcategories}leoclot>blockcategories_d5e74c74b1457c285adc8b2c2ab03767'] = 'Ustaw ilość kolumn stopki';
$_MODULE['<{blockcategories}leoclot>blockcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{blockcategories}leoclot>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Kategorie';
$_MODULE['<{blockcategories}leoclot>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Kategorie';
