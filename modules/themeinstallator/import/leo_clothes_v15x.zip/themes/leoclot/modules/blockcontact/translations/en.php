<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcontact}prestashop>blockcontact_8b1f7be76996ad6911a17592b9804e1b'] = 'Our support hotline is available 24/7.';
$_MODULE['<{blockcontact}prestashop>blockcontact_e6d0e56415c30a59658fb34ef5d7be35'] = 'Contact our expert support team!';
