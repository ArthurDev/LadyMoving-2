<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockadvertising}leoclot>blockadvertising_fd4c71c948857cce596a69fbaea7426b'] = 'Blok advertenties';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_91cd1ee56ea5324ff51578684a393a81'] = 'Voegt een blok toe voor het weergeven van een advertentie.';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_070e16b4f77b90e802f789b5be583cfa'] = 'Fout opgetreden tijdens het verplaatsen van het geüploade bestand';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_6e7be6d836003f069c00cd217660913b'] = 'Advertentieblok configuratie';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_a21056e22c4d62b400b5dd96dafe22a3'] = 'U kunt de standaardafbeelding niet verwijderen (maar u kunt het hieronder veranderen).';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_83b5a65e518c21ed0a5f2b383dd9b617'] = 'Verwijder afbeelding';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_9dd7104e68d1b5f994264b9387c9d271'] = 'geen afbeelding';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_8c38cf08a0d0a01bd44c682479432350'] = 'Wijzig afbeelding';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_56d9dfa26d7848a3fbcd2ae3091d38d9'] = 'Afbeelding zal als 155x163 worden weergegeven';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_9ce38727cff004a058021a6c7351a74a'] = 'Afbeelding link';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_b78a3223503896721cca1303f776159b'] = 'Titel';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_ad3d06d03d94223fa652babc913de686'] = 'Valideer';
