<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockadvertising}leoclot>blockadvertising_fd4c71c948857cce596a69fbaea7426b'] = 'Рекламный блок';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_91cd1ee56ea5324ff51578684a393a81'] = 'Добавляет блок для отображения рекламы.';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_070e16b4f77b90e802f789b5be583cfa'] = 'Ошибка при копировании загруженного файла';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_6e7be6d836003f069c00cd217660913b'] = 'Конфигурация рекламного блока';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_a21056e22c4d62b400b5dd96dafe22a3'] = 'Нельзя удалить изображение, используемое по умолчанию (но вы можете изменить его ниже).';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_83b5a65e518c21ed0a5f2b383dd9b617'] = 'Удалить изображение';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_9dd7104e68d1b5f994264b9387c9d271'] = 'нет изображения';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_8c38cf08a0d0a01bd44c682479432350'] = 'Изменить изображение';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_56d9dfa26d7848a3fbcd2ae3091d38d9'] = 'Изображение будет отображаться как 155x163';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_9ce38727cff004a058021a6c7351a74a'] = 'Ссылка на изображение';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_b78a3223503896721cca1303f776159b'] = 'Название';
$_MODULE['<{blockadvertising}leoclot>blockadvertising_ad3d06d03d94223fa652babc913de686'] = 'Проверить';
