<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontactinfos}leoclot>blockcontactinfos_632535e0cdfd3380906f6b7d40ba78d3'] = 'Bloquear informações sobre contato';
$_MODULE['<{blockcontactinfos}leoclot>blockcontactinfos_86458ae1631be34a6fcbf1a4584f5abe'] = 'Adicione um bloco para acrescentar algumas informações sobre como contatar a loja';
$_MODULE['<{blockcontactinfos}leoclot>blockcontactinfos_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configurações atualizadas.';
$_MODULE['<{blockcontactinfos}leoclot>blockcontactinfos_c281f92b77ba329f692077d23636f5c9'] = 'Nome da Empresa';
$_MODULE['<{blockcontactinfos}leoclot>blockcontactinfos_dd7bf230fde8d4836917806aff6a6b27'] = 'Endereço';
$_MODULE['<{blockcontactinfos}leoclot>blockcontactinfos_1f8261d17452a959e013666c5df45e07'] = 'Número de telefone';
$_MODULE['<{blockcontactinfos}leoclot>blockcontactinfos_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{blockcontactinfos}leoclot>blockcontactinfos_b17f3f4dcf653a5776792498a9b44d6a'] = 'Atualizar configurações';
$_MODULE['<{blockcontactinfos}leoclot>blockcontactinfos_02d4482d332e1aef3437cd61c9bcc624'] = 'Fale conosco';
$_MODULE['<{blockcontactinfos}leoclot>blockcontactinfos_2e006b735fbd916d8ab26978ae6714d4'] = 'Tel:';
