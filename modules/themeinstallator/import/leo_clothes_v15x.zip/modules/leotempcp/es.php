<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{thmskins}prestashop>thmskins_f5cf47ab06d0d98b0d16d10c82d87953'] = 'Actualizar ';
