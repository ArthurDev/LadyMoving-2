<?php 
$this->moduleObj->l('Global Option');
$this->moduleObj->l('Theme');
$this->moduleObj->l('Title');
$this->moduleObj->l('Show/hide title');
$this->moduleObj->l('Item Count');
$this->moduleObj->l('List Ordering');
 ?>