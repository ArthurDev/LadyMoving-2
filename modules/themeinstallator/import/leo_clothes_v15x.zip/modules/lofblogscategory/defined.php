<?php
/**
 * @name defined.php
 * @author landOfCoder
 * @todo defined some path and link
 */

// *************** SOME PATHS ******************************
define('LOFCONTENTMENU_ROOT', _PS_MODULE_DIR_ . 'lofblogscategory/');
define('LOFCONTENTMENU_HTML', LOFCONTENTMENU_ROOT.'html/');
define('LOFCONTENTMENU_LIB', LOFCONTENTMENU_ROOT.'libs/');
define('LOFCONTENTMENU_THEME', LOFCONTENTMENU_ROOT.'themes/');

// ***************** SOME LINKS ***************************************

define('LOFCONTENTMENU_BASE_URI', __PS_BASE_URI__ . 'modules/lofblogscategory/');

?>
