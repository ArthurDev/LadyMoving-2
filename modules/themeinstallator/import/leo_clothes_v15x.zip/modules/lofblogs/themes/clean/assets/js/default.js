$(window).load(function() {
    $('#articleGallery a').prettyPhoto({
        social_tools: false
    });
});