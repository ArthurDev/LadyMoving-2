<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<input class="gallery_upload_field" onChange="reportFilesSelected()" type="file" name="ga_upload_field[]" id="ga_upload_field" multiple="" />
<fieldset>
    <legend>Files Selected</legend>
    <ul id="upload_list"><li><span>Please select some image ("Ctrl + left click" on image to select multiple image)</span></li></ul>    
</fieldset>