<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{lofcontent}prestashop>adminlofcontent_ec53a8c4f07baed5d8825072c89799be'] = 'Trạng thái';
$_MODULE['<{lofcontent}prestashop>adminlofcontent_b78a3223503896721cca1303f776159b'] = 'Tiêu đề';
$_MODULE['<{lofcontent}prestashop>adminlofcontent_735f7bed9808abe3b3c6bb67b9634a31'] = 'Ngày viết';
$_MODULE['<{lofcontent}prestashop>adminlofcontent_49ee3087348e8d44e1feda1917443987'] = 'Tên';
$_MODULE['<{lofcontent}prestashop>adminlofcontent_af1b98adf7f686b84cd0b443e022b7a0'] = 'Chuyện mục';
$_MODULE['<{lofcontent}prestashop>adminlofcontentcategory_bb34a159a88035cce7ef1607e7907f8f'] = 'Tên chuyên mục';
$_MODULE['<{lofcontent}prestashop>adminlofcontentcategory_da34b779ef04872077280e7e6a5cf60f'] = 'Thêm mới / cập nhật chuyên mục';
$_MODULE['<{lofcontent}prestashop>lof_category_49ee3087348e8d44e1feda1917443987'] = 'Tên';
$_MODULE['<{lofcontent}prestashop>lof_category_effdb9ce6c5d44df31b89d7069c8e0fb'] = 'Tên URL';
$_MODULE['<{lofcontent}prestashop>lof_category_38fb7d24e0d60a048f540ecb18e13376'] = 'Cập nhật';
