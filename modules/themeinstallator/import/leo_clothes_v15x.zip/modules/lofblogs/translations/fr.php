<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{lofcontent}prestashop>adminlofcontentcategory_3e076fd75287c8777019dc080fd16887'] = 'Sous-catégories gestionnaire - ';
$_MODULE['<{lofcontent}prestashop>form_06933067aafd48425d67bcb01bba5cb6'] = 'mettre à jour';
$_MODULE['<{lofcontent}prestashop>params_lang_4ede758053afb49f54ea2ef0d5276910'] = 'options générales';
$_MODULE['<{lofcontent}prestashop>params_lang_c4d100408c2592f5441b6156a08533dd'] = 'Largeur primaire';
$_MODULE['<{lofcontent}prestashop>params_lang_7204d074896d0a5e5e29900282c46fe9'] = 'hauteur primaire';
$_MODULE['<{lofcontent}prestashop>params_lang_428872304039eb06a8761dec0d58c59a'] = 'largeur Vignette';
