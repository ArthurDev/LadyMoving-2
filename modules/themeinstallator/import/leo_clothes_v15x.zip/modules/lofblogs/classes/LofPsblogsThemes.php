<?php

/**
 * Admin class - LofPscontentPublication
 * 
 * @Project Lof Content
 * @todo Get articles data.
 */
require_once LOFCONTENT_LIBS_FOLDER . 'lof_content_helper.php';

class LofPsblogsThemes extends ObjectModel { 

}
