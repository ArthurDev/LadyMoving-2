DROP TABLE IF EXISTS `ps_leomanagewidgets`;
DROP TABLE IF EXISTS `ps_leomanagewidgets_shop`;
DROP TABLE IF EXISTS `ps_leomanagewidgets_exceptions`;